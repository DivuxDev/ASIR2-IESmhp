<html>
<link rel="stylesheet" href="cssphp.css">
<nav>
  <!--barra lateral-->
  <ul>
    <li><a href="panel.php">Inicio</a></li>
    <li><a href="insertarclientes.php">Insertar clientes</a></li>
    <li><a href="insertarempleados.php">Insertar empleados</a></li>
    <li><a href="insertarproveedores.php">Insertar proveedores</a></li>
    <li><a href="insertarproductos.php">Insertar productos</a></li>
    <li><a href="listarnominas.php">Listar nominas</a></li>
    <li><a href="listarproveedores.php">Listar proveedores</a></li>
    <li><a href="listarproductos.php">Listar productos</a></li>
    <li><a href="mostrarproductos.php">comprar productos</a></li>
   
  </ul>
</nav>
<div class="panelcentral">
  <div style="margin-left:15%">
<!-- php -->
    <?php
    //cvariable de la BD
  $hostname = "localhost";
  $user = "root";
  $pwd = "";
  $dbname = "empresa";

  // Conectando, seleccionando la base de datos
  if (!$conect = mysqli_connect($hostname, $user, $pwd, $dbname)) {
    die("no se ha podido conectar al SGBD");
  }
  //saco los datos los proveedores y los productos
  $sql = "SELECT * FROM productos";

  $result = mysqli_query($conect, $sql);
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      //muestro los datos
      echo "
    <table>
    <tr>
    <th>ID Producto</th>
      <th>Nombre producto</th>
      <th>Precio €</th>
      <th>Stock</th>
    </tr>
    <tr>
    <td>" . $row["id_producto"] . "</td>
    <td>" . $row["nombre"] . "</td>
    <td>" . $row["precio"] . "</td>
    <td>" . $row["stock"] . "</td>
    </tr>
  </table>";
    }
  } else {
    echo "Todavia no se ha añadido ningun registro";
  };
  // Cerrar la conexión
  mysqli_close($conect);
  ?>

    <br>
    <table>
      <th>
<!--boton de submit e ID para ingresar la ID del producto que quiero comprar-->
        <form action='ingresardatos.php' method='POST'>
      <td>
        Id Producto: <input type="text" name="id_producto"><br><br>
      </td>
    </table>
    <input type="submit" name="submit" value="Insertar productos">
    <input class="botoninicio" type="reset" value="Resetear">
    </form>
  </div>
</div>

</html>