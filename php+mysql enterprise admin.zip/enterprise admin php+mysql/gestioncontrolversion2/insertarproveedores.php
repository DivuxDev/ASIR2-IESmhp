<html>
<link rel="stylesheet" href="cssphp.css">
<body>
<nav>
    <!--barra lateral-->
<ul>
        <li><a href="panel.php">Inicio</a></li>
        <li><a href="insertarclientes.php">Insertar clientes</a></li>
        <li><a href="insertarempleados.php">Insertar empleados</a></li>
        <li><a href="insertarproveedores.php">Insertar proveedores</a></li>
        <li><a href="insertarproductos.php">Insertar productos</a></li>
        <li><a href="listarnominas.php">Listar nominas</a></li>
        <li><a href="listarproveedores.php">Listar proveedores</a></li>
        <li><a href="listarproductos.php">Listar productos</a></li>
        <li><a href="mostrarproductos.php">comprar productos</a></li>
    </ul>
</nav>
<div class="panelcentral">
<h1>Formulario de insercion de proveedores</h1>
<!--inicio del formulario-->
<form  action="insertarproveedores.php" method="POST">
    Nombre: <input type="text" name="nombre" ><br><br>
    Correo: <input type="text" name="correo"><br><br>
    <input type="submit" name="submit" value="Insertar proveedores"><br><br>
    <input class="botoninicio" type="reset" value="Resetear">
</form>
<?php
//variables de la BD

$hostname = "localhost";
$user = "root";
$pwd = "";
$dbname = "empresa";
// SI submit ha sido presionado y nombre esta rellenado se cumple la condicion

if (isset($_POST['submit']) && !empty($nombre=$_POST["nombre"])){
// Conectando, seleccionando la base de datos
if (!$conect = mysqli_connect($hostname, $user, $pwd,$dbname)) {
    die("no se ha podido conectar al SGBD");
}
//recogo las variables de formulario

$nombre= $_POST["nombre"];
$correo=$_POST["correo"];
//genero la orden insert

$insert= "insert into proveedores values
(NULL,'".$nombre."','".$correo."')";
//ejecuto la orden insert

if (mysqli_query($conect,$insert) === TRUE) {
    echo "Se ha insertado correctamente";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
// Cerrar la conexión
mysqli_close($conect);
}else {}
?>
</div>


</div>
</body>

</html>