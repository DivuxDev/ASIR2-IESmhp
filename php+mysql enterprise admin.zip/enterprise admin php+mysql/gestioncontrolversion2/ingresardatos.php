<html>
<link rel="stylesheet" href="cssphp.css">
<nav>
  <!-- barra lateral -->
  <ul>
    <li><a href="panel.php">Inicio</a></li>
    <li><a href="insertarclientes.php">Insertar clientes</a></li>
    <li><a href="insertarempleados.php">Insertar empleados</a></li>
    <li><a href="insertarproveedores.php">Insertar proveedores</a></li>
    <li><a href="insertarproductos.php">Insertar productos</a></li>
    <li><a href="listarnominas.php">Listar nominas</a></li>
    <li><a href="listarproveedores.php">Listar proveedores</a></li>
    <li><a href="listarproductos.php">Listar productos</a></li>
    <li><a href="mostrarproductos.php">comprar productos</a></li>

  </ul>
</nav>
<!--recogo la variable sumbit y el id de producto -->
<?php
if (isset($_POST['submit']))
{
$p=$_POST["id_producto"];

}
?>
<div class="panelcentral">
<form action='resumen.php' method='POST'>
<!--meto el id de producto en el value de un input en formato hidden para poder tenerlo en este formulario-->
<input type='hidden' name='id_producto' value=<?php echo $p?>>
Nombre:<input type='text' name='nombrecliente'><br>
Direccion de envio:<input type='text' name='direccioncliente'><br>
Numero de tarjeta:<input type='text' name='tarjetacliente'><br>
<input type="submit" name="submit" value="Insertar datos de cliente"><br><br>
<input class="botoninicio" type="reset" value="Resetear">
</div>
</html>
