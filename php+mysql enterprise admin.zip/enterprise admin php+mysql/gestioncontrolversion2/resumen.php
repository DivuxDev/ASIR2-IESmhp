<html>
<link rel="stylesheet" href="cssphp.css">
<nav>
  <ul>
    <li><a href="panel.php">Inicio</a></li>
    <li><a href="insertarclientes.php">Insertar clientes</a></li>
    <li><a href="insertarempleados.php">Insertar empleados</a></li>
    <li><a href="insertarproveedores.php">Insertar proveedores</a></li>
    <li><a href="insertarproductos.php">Insertar productos</a></li>
    <li><a href="listarnominas.php">Listar nominas</a></li>
    <li><a href="listarproveedores.php">Listar proveedores</a></li>
    <li><a href="listarproductos.php">Listar productos</a></li>

  </ul>
</nav>
<div class="panelcentral">
  <div style="margin-left:15%">
    <?php 
//recogo las variables del formulario anterior
      $producto=$_POST["id_producto"];
      $nombre=$_POST["nombrecliente"];
      $direccion=$_POST["direccioncliente"];
      $tarjeta=$_POST["tarjetacliente"];
// variable de bd
      $hostname = "localhost";
      $user = "root";
      $pwd = "";
      $dbname = "empresa";
     
      // Conectando, seleccionando la base de datos
      if (!$conect = mysqli_connect($hostname, $user, $pwd, $dbname)) {
        die("no se ha podido conectar al SGBD");}
      //saco los datos los proveedores y los productos
      $sql = "select * from productos where id_producto =".$producto;

      $result = mysqli_query($conect, $sql);
      if ($result->num_rows > 0) {
          // output data of each row
          while ($row = $result->fetch_assoc()) 
          {$nombrep=$row["nombre"];
          $preciop=$row["precio"];} 
      }
      ?>
<!--genero la tabla-->
    <h1>Datos de compra </h1>
    <table>
      <tr>
        <th>Nombre del cliente</th>
        <th>Direccion del cliente</th>
        <th>cuenta del cliente</th>
        <th>Nombre del producto</th>
        <th>precio del producto €</th>
      </tr>
      <tr>
<!-- muestro los datos del formulario anterior -->
        <td>
          <?php echo $nombre ?>
        </td>
        <td>
          <?php echo $direccion ?>
        </td>
        <td>
          <?php echo $tarjeta ?>
        </td>
        <td>
          <?php echo $nombrep ?>
        </td>
        <td>
          <?php echo $preciop ?>
        </td>
      </tr>
  </div>
</div>

</html>